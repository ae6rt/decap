#!/bin/bash

set -x

echo hello world on branch ${BRANCH_TO_BUILD}

