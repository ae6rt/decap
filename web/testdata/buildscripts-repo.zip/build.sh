#!/bin/bash

echo hello from Github: build branch ${BRANCH_TO_BUILD}
